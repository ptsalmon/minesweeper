
// Global function prototypes

int launch();
void restart();
void render();
void toggleDebugMode();
bool getDebugMode();
int gameLoop();